# 6. Positive, Negative or Zero

num = int(input("Enter a number: "))

if num > 0:
    print("Positive number")
elif num < 0:
    print("Negative number")
else:
    print("Zero")

# VERIFIED SAMPLE OUTPUT
# Input: -7
# Negative number
