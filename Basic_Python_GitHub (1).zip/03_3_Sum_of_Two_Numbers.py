# 3. Sum of Two Numbers

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
print("Sum =", a + b)

# VERIFIED SAMPLE OUTPUT
# Input: 10, 20
# Sum = 30
