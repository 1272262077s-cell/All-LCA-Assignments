# 1. Hello World

print("Hello, World!")

# VERIFIED SAMPLE OUTPUT
# Input: No input
# Hello, World!
