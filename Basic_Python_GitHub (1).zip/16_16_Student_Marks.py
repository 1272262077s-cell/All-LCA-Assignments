# 16. Student Marks

student_name = input("Enter student name: ")
roll_no = input("Enter roll number: ")

maths = float(input("Enter marks in Mathematics: "))
physics = float(input("Enter marks in Physics: "))
chemistry = float(input("Enter marks in Chemistry: "))

total = maths + physics + chemistry
percentage = total / 3

marks = {
    "Mathematics": maths,
    "Physics": physics,
    "Chemistry": chemistry
}

highest_subject = max(marks, key=marks.get)
lowest_subject = min(marks, key=marks.get)

print("\nStudent Name:", student_name)
print("Roll Number:", roll_no)
print("Percentage:", percentage, "%")
print("Subject with Highest Marks:", highest_subject)
print("Subject with Lowest Marks:", lowest_subject)

# VERIFIED SAMPLE OUTPUT
# Input: Sakshi, 10, 90, 80, 70
# Student Name: Sakshi
# Roll Number: 10
# Percentage: 80.0 %
# Subject with Highest Marks: Mathematics
# Subject with Lowest Marks: Chemistry
