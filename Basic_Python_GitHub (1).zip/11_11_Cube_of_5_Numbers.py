# 11. Cube of 5 Numbers

for i in range(1, 6):
    num = int(input(f"Enter number {i}: "))
    print("Cube =", num ** 3)

# VERIFIED SAMPLE OUTPUT
# Input: 1, 2, 3, 4, 5
# Cube = 1
# Cube = 8
# Cube = 27
# Cube = 64
# Cube = 125
