# 14. Grade

marks = int(input("Enter marks in Mathematics: "))

if marks >= 90 and marks <= 100:
    print("Grade: O")
elif marks >= 80 and marks <= 89:
    print("Grade: A+")
elif marks >= 70 and marks <= 79:
    print("Grade: A")
elif marks >= 60 and marks <= 69:
    print("Grade: B")
elif marks >= 50 and marks <= 59:
    print("Grade: C")
elif marks >= 40 and marks <= 49:
    print("Grade: P")
elif marks >= 0 and marks < 40:
    print("Grade: F")
else:
    print("Invalid marks")

# VERIFIED SAMPLE OUTPUT
# Input: 85
# Grade: A+
