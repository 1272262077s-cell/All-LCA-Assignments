# 12. Reverse a Number

num = int(input("Enter a number: "))

reverse = 0
while num > 0:
    digit = num % 10
    reverse = reverse * 10 + digit
    num //= 10

print("Reversed number =", reverse)

# VERIFIED SAMPLE OUTPUT
# Input: 12345
# Reversed number = 54321
