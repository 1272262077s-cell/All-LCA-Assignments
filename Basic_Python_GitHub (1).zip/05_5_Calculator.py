# 5. Calculator

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

print("Addition =", a + b)
print("Subtraction =", a - b)
print("Multiplication =", a * b)

if b != 0:
    print("Division =", a / b)
else:
    print("Division is not possible by zero")

# VERIFIED SAMPLE OUTPUT
# Input: 20, 5
# Addition = 25.0
# Subtraction = 15.0
# Multiplication = 100.0
# Division = 4.0
