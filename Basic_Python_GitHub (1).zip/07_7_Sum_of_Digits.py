# 7. Sum of Digits

num = int(input("Enter a number: "))
num = abs(num)

sum_digits = 0
while num > 0:
    digit = num % 10
    sum_digits += digit
    num //= 10

print("Sum of digits =", sum_digits)

# VERIFIED SAMPLE OUTPUT
# Input: 12345
# Sum of digits = 15
