# 15. Student Details

print("Student Name: Sakshi")
print("Address: Pune")
print("Contact No: 9876543210")
print("Mother Tongue: Sindhi")
print("School Name: ABC School")
print("Year: 2026")
print("Panel: A")
print("Roll No: 10")

# VERIFIED SAMPLE OUTPUT
# Input: Sample student details
# Student Name: Sakshi
# Address: Pune
# Contact No: 9876543210
# Mother Tongue: Sindhi
# School Name: ABC School
# Year: 2026
# Panel: A
# Roll No: 10
