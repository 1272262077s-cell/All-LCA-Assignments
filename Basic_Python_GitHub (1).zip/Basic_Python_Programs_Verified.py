# BASIC PYTHON PROGRAMS — VERIFIED SAMPLE RUNS

# ======================================================================
# 1. Hello World
# ======================================================================

print("Hello, World!")

# VERIFIED SAMPLE OUTPUT
# Input: No input
# Hello, World!

# ======================================================================
# 2. Largest of Three Numbers
# ======================================================================

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))

if a >= b and a >= c:
    largest = a
elif b >= a and b >= c:
    largest = b
else:
    largest = c

print("Largest number is:", largest)

# VERIFIED SAMPLE OUTPUT
# Input: 10, 25, 15
# Largest number is: 25

# ======================================================================
# 3. Sum of Two Numbers
# ======================================================================

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
print("Sum =", a + b)

# VERIFIED SAMPLE OUTPUT
# Input: 10, 20
# Sum = 30

# ======================================================================
# 4. Even or Odd
# ======================================================================

num = int(input("Enter a number: "))

if num % 2 == 0:
    print("Even number")
else:
    print("Odd number")

# VERIFIED SAMPLE OUTPUT
# Input: 8
# Even number

# ======================================================================
# 5. Calculator
# ======================================================================

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

print("Addition =", a + b)
print("Subtraction =", a - b)
print("Multiplication =", a * b)

if b != 0:
    print("Division =", a / b)
else:
    print("Division is not possible by zero")

# VERIFIED SAMPLE OUTPUT
# Input: 20, 5
# Addition = 25.0
# Subtraction = 15.0
# Multiplication = 100.0
# Division = 4.0

# ======================================================================
# 6. Positive, Negative or Zero
# ======================================================================

num = int(input("Enter a number: "))

if num > 0:
    print("Positive number")
elif num < 0:
    print("Negative number")
else:
    print("Zero")

# VERIFIED SAMPLE OUTPUT
# Input: -7
# Negative number

# ======================================================================
# 7. Sum of Digits
# ======================================================================

num = int(input("Enter a number: "))
num = abs(num)

sum_digits = 0
while num > 0:
    digit = num % 10
    sum_digits += digit
    num //= 10

print("Sum of digits =", sum_digits)

# VERIFIED SAMPLE OUTPUT
# Input: 12345
# Sum of digits = 15

# ======================================================================
# 8. Factorial
# ======================================================================

num = int(input("Enter a number: "))

if num < 0:
    print("Factorial is not defined for negative numbers")
else:
    factorial = 1
    for i in range(1, num + 1):
        factorial *= i
    print("Factorial =", factorial)

# VERIFIED SAMPLE OUTPUT
# Input: 5
# Factorial = 120

# ======================================================================
# 9. Prime Check
# ======================================================================

num = int(input("Enter a number: "))

if num < 2:
    print("Not a prime number")
else:
    is_prime = True
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            is_prime = False
            break

    if is_prime:
        print("Prime number")
    else:
        print("Not a prime number")

# VERIFIED SAMPLE OUTPUT
# Input: 17
# Prime number

# ======================================================================
# 10. Prime Numbers 10 to 99
# ======================================================================

print("Prime numbers between 10 and 99 are:")

for num in range(10, 100):
    is_prime = True
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            is_prime = False
            break
    if is_prime:
        print(num, end=" ")

# VERIFIED SAMPLE OUTPUT
# Input: No input
# Prime numbers between 10 and 99 are:
# 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97

# ======================================================================
# 11. Cube of 5 Numbers
# ======================================================================

for i in range(1, 6):
    num = int(input(f"Enter number {i}: "))
    print("Cube =", num ** 3)

# VERIFIED SAMPLE OUTPUT
# Input: 1, 2, 3, 4, 5
# Cube = 1
# Cube = 8
# Cube = 27
# Cube = 64
# Cube = 125

# ======================================================================
# 12. Reverse a Number
# ======================================================================

num = int(input("Enter a number: "))

reverse = 0
while num > 0:
    digit = num % 10
    reverse = reverse * 10 + digit
    num //= 10

print("Reversed number =", reverse)

# VERIFIED SAMPLE OUTPUT
# Input: 12345
# Reversed number = 54321

# ======================================================================
# 13. Leap Year
# ======================================================================

year = int(input("Enter a year: "))

if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0):
    print("Leap year")
else:
    print("Not a leap year")

# VERIFIED SAMPLE OUTPUT
# Input: 2024
# Leap year

# ======================================================================
# 14. Grade
# ======================================================================

marks = int(input("Enter marks in Mathematics: "))

if marks >= 90 and marks <= 100:
    print("Grade: O")
elif marks >= 80 and marks <= 89:
    print("Grade: A+")
elif marks >= 70 and marks <= 79:
    print("Grade: A")
elif marks >= 60 and marks <= 69:
    print("Grade: B")
elif marks >= 50 and marks <= 59:
    print("Grade: C")
elif marks >= 40 and marks <= 49:
    print("Grade: P")
elif marks >= 0 and marks < 40:
    print("Grade: F")
else:
    print("Invalid marks")

# VERIFIED SAMPLE OUTPUT
# Input: 85
# Grade: A+

# ======================================================================
# 15. Student Details
# ======================================================================

print("Student Name: Sakshi")
print("Address: Pune")
print("Contact No: 9876543210")
print("Mother Tongue: Sindhi")
print("School Name: ABC School")
print("Year: 2026")
print("Panel: A")
print("Roll No: 10")

# VERIFIED SAMPLE OUTPUT
# Input: Sample student details
# Student Name: Sakshi
# Address: Pune
# Contact No: 9876543210
# Mother Tongue: Sindhi
# School Name: ABC School
# Year: 2026
# Panel: A
# Roll No: 10

# ======================================================================
# 16. Student Marks
# ======================================================================

student_name = input("Enter student name: ")
roll_no = input("Enter roll number: ")

maths = float(input("Enter marks in Mathematics: "))
physics = float(input("Enter marks in Physics: "))
chemistry = float(input("Enter marks in Chemistry: "))

total = maths + physics + chemistry
percentage = total / 3

marks = {
    "Mathematics": maths,
    "Physics": physics,
    "Chemistry": chemistry
}

highest_subject = max(marks, key=marks.get)
lowest_subject = min(marks, key=marks.get)

print("\nStudent Name:", student_name)
print("Roll Number:", roll_no)
print("Percentage:", percentage, "%")
print("Subject with Highest Marks:", highest_subject)
print("Subject with Lowest Marks:", lowest_subject)

# VERIFIED SAMPLE OUTPUT
# Input: Sakshi, 10, 90, 80, 70
# Student Name: Sakshi
# Roll Number: 10
# Percentage: 80.0 %
# Subject with Highest Marks: Mathematics
# Subject with Lowest Marks: Chemistry

