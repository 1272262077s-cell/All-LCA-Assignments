# Basic Python Programs

16 basic Python programs with sample inputs and verified expected outputs.

## Programs
1. Hello World
2. Largest of Three Numbers
3. Sum of Two Numbers
4. Even or Odd
5. Calculator
6. Positive, Negative or Zero
7. Sum of Digits
8. Factorial
9. Prime Number Check
10. Prime Numbers Between 10 and 99
11. Cube Values of 5 Numbers
12. Reverse a Number
13. Leap Year
14. Grade According to Marks
15. Student Details and Multi-line Comments
16. Student Marks, Percentage, Highest and Lowest Subject

Open `Basic_Python_Programs_Verified.py` if you want everything in one file.
