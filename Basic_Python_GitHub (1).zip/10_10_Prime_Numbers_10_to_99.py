# 10. Prime Numbers 10 to 99

print("Prime numbers between 10 and 99 are:")

for num in range(10, 100):
    is_prime = True
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            is_prime = False
            break
    if is_prime:
        print(num, end=" ")

# VERIFIED SAMPLE OUTPUT
# Input: No input
# Prime numbers between 10 and 99 are:
# 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97
